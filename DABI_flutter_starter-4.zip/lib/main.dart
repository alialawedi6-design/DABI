import 'package:flutter/material.dart';

void main() => runApp(const DabiApp());

class DabiApp extends StatelessWidget {
  const DabiApp({super.key});

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFFB8F500);
    const navy = Color(0xFF071426);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'DABI',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        colorScheme: ColorScheme.fromSeed(
          seedColor: green,
          brightness: Brightness.light,
        ),
      ),
      home: const RideHomePage(),
    );
  }
}

class RideHomePage extends StatefulWidget {
  const RideHomePage({super.key});

  @override
  State<RideHomePage> createState() => _RideHomePageState();
}

class _RideHomePageState extends State<RideHomePage> {
  String pickup = 'موقعي الحالي — طور سيناء';
  String destination = '';
  String selectedRide = 'اقتصادي';
  bool searching = false;

  static const green = Color(0xFFB8F500);
  static const navy = Color(0xFF071426);

  void requestRide() {
    if (destination.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اكتب وجهتك الأول')),
      );
      return;
    }
    setState(() => searching = true);
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('طلب مشوار دابي'),
        content: Text(
          'تم تجهيز طلبك التجريبي إلى $destination.\n'
          'النسخة الحالية واجهة تجريبية؛ سيتم ربطها بالسائقين والخرائط في المرحلة التالية.',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() => searching = false);
            },
            child: const Text('تمام'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            const _MapMock(),
            Positioned(
              top: 16,
              right: 16,
              left: 16,
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: navy,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Center(
                      child: Text(
                        'D',
                        style: TextStyle(
                          color: green,
                          fontWeight: FontWeight.w900,
                          fontSize: 28,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'DABI',
                        style: TextStyle(
                          fontSize: 23,
                          fontWeight: FontWeight.w900,
                          color: navy,
                          letterSpacing: 1.2,
                        ),
                      ),
                      Text(
                        'دابي.. مشوارك أسهل',
                        style: TextStyle(fontSize: 12, color: navy),
                      ),
                    ],
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: () {},
                    style: IconButton.styleFrom(
                      backgroundColor: Colors.white,
                    ),
                    icon: const Icon(Icons.menu, color: navy),
                  ),
                ],
              ),
            ),
            Positioned(
              right: 16,
              bottom: 16,
              left: 16,
              child: _RidePanel(
                pickup: pickup,
                destination: destination,
                selectedRide: selectedRide,
                onDestinationChanged: (value) =>
                    setState(() => destination = value),
                onRideSelected: (value) =>
                    setState(() => selectedRide = value),
                onRequest: requestRide,
                searching: searching,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MapMock extends StatelessWidget {
  const _MapMock();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFFE5EAF0),
      child: Stack(
        fit: StackFit.expand,
        children: [
          CustomPaint(painter: _MapPainter()),
          Positioned(
            left: 70,
            top: 250,
            child: Transform.rotate(
              angle: -0.4,
              child: const Icon(Icons.navigation, size: 30, color: Colors.blue),
            ),
          ),
          Positioned(
            right: 90,
            top: 180,
            child: _MapPin(color: const Color(0xFF071426), icon: Icons.location_on),
          ),
          Positioned(
            left: 40,
            bottom: 330,
            child: _MapPin(color: const Color(0xFFB8F500), icon: Icons.my_location),
          ),
          Positioned(
            right: 16,
            top: 100,
            child: FloatingActionButton.small(
              backgroundColor: Colors.white,
              foregroundColor: const Color(0xFF071426),
              onPressed: () {},
              child: const Icon(Icons.my_location),
            ),
          ),
        ],
      ),
    );
  }
}

class _MapPin extends StatelessWidget {
  final Color color;
  final IconData icon;
  const _MapPin({required this.color, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(color: color.withOpacity(.25), blurRadius: 15, spreadRadius: 3),
        ],
      ),
      child: Icon(icon, color: color == const Color(0xFFB8F500) ? Colors.black : Colors.white),
    );
  }
}

class _MapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final road = Paint()
      ..color = Colors.white
      ..strokeWidth = 16
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final thinRoad = Paint()
      ..color = Colors.white.withOpacity(.85)
      ..strokeWidth = 7
      ..style = PaintingStyle.stroke;
    final blocks = Paint()..color = const Color(0xFFD7E0E8);

    for (int i = 0; i < 9; i++) {
      final y = 70.0 + i * 70;
      canvas.drawLine(Offset(0, y), Offset(size.width, y + 20), thinRoad);
    }
    for (int i = 0; i < 7; i++) {
      final x = i * 65.0;
      canvas.drawLine(Offset(x, 0), Offset(x + 90, size.height), thinRoad);
    }

    final route = Path()
      ..moveTo(size.width * .20, size.height * .62)
      ..lineTo(size.width * .32, size.height * .55)
      ..lineTo(size.width * .32, size.height * .44)
      ..lineTo(size.width * .52, size.height * .44)
      ..lineTo(size.width * .52, size.height * .30)
      ..lineTo(size.width * .72, size.height * .30);
    canvas.drawPath(route, road);
    final routeGreen = Paint()
      ..color = const Color(0xFFB8F500)
      ..strokeWidth = 5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(route, routeGreen);

    final park = Paint()..color = const Color(0xFFD0E4CF);
    canvas.drawRect(Rect.fromLTWH(size.width * .05, size.height * .20, 90, 90), park);
    canvas.drawRect(Rect.fromLTWH(size.width * .65, size.height * .50, 110, 80), park);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _RidePanel extends StatelessWidget {
  final String pickup;
  final String destination;
  final String selectedRide;
  final ValueChanged<String> onDestinationChanged;
  final ValueChanged<String> onRideSelected;
  final VoidCallback onRequest;
  final bool searching;

  const _RidePanel({
    required this.pickup,
    required this.destination,
    required this.selectedRide,
    required this.onDestinationChanged,
    required this.onRideSelected,
    required this.onRequest,
    required this.searching,
  });

  static const green = Color(0xFFB8F500);
  static const navy = Color(0xFF071426);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.12),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 42,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'رايح فين؟',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: navy),
          ),
          const SizedBox(height: 14),
          _LocationRow(
            icon: Icons.my_location,
            color: green,
            title: 'من',
            value: pickup,
          ),
          const SizedBox(height: 8),
          _LocationRow(
            icon: Icons.location_on,
            color: Colors.redAccent,
            title: 'إلى',
            value: '',
            child: TextField(
              onChanged: onDestinationChanged,
              textAlign: TextAlign.right,
              decoration: const InputDecoration(
                hintText: 'اكتب وجهتك',
                border: InputBorder.none,
                isDense: true,
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'اختار نوع الرحلة',
            style: TextStyle(fontWeight: FontWeight.bold, color: navy),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              _RideOption(
                name: 'اقتصادي',
                icon: Icons.directions_car,
                price: 'السعر حسب المسافة',
                selected: selectedRide == 'اقتصادي',
                onTap: () => onRideSelected('اقتصادي'),
              ),
              const SizedBox(width: 8),
              _RideOption(
                name: 'مريح',
                icon: Icons.local_taxi,
                price: 'سيارة أكبر',
                selected: selectedRide == 'مريح',
                onTap: () => onRideSelected('مريح'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            height: 54,
            child: ElevatedButton(
              onPressed: onRequest,
              style: ElevatedButton.styleFrom(
                backgroundColor: green,
                foregroundColor: navy,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 0,
              ),
              child: Text(
                searching ? 'جاري تجهيز الطلب...' : 'اطلب مشوار',
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Center(
            child: Text(
              'DABI • دابي.. مشوارك أسهل',
              style: TextStyle(fontSize: 11, color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }
}

class _LocationRow extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String value;
  final Widget? child;

  const _LocationRow({
    required this.icon,
    required this.color,
    required this.title,
    required this.value,
    this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFFF4F6F8),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(width: 10),
          Text(title, style: const TextStyle(color: Colors.grey)),
          const SizedBox(width: 10),
          Expanded(child: child ?? Text(value, textAlign: TextAlign.right)),
        ],
      ),
    );
  }
}

class _RideOption extends StatelessWidget {
  final String name;
  final IconData icon;
  final String price;
  final bool selected;
  final VoidCallback onTap;

  const _RideOption({
    required this.name,
    required this.icon,
    required this.price,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFFB8F500);
    const navy = Color(0xFF071426);
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            border: Border.all(
              color: selected ? navy : Colors.grey.shade300,
              width: selected ? 2 : 1,
            ),
            borderRadius: BorderRadius.circular(14),
            color: selected ? green.withOpacity(.20) : Colors.white,
          ),
          child: Column(
            children: [
              Icon(icon, color: navy, size: 26),
              const SizedBox(height: 5),
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(price, textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 10, color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}
